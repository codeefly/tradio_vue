<template>
  <data-layout :active="3">
    <div class="col-xl-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Insurance Fund Balance</h4>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Start Time</th>
                  <th>Balance</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
                <tr>
                  <td>15th March, 2020</td>
                  <td>1.0215 BTC</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </data-layout>
</template>

<script>
import DataLayout from "../../../components/Layouts/DataLayout.vue";
export default {
  components: { DataLayout },
};
</script>
